#  Encode Decoder Pro

###  Author: Sheethal  
###  Roll No: 251100670032  
###  Course: BDA  
###  Docker Hub: https://hub.docker.com/repositories/sheethalrao94

---

##  Project Overview

Encode Decoder Pro is a complete compression visualization platform implementing multiple encoding and decoding algorithms with interactive tree visualization.

The system includes:

-  Static Huffman Coding
-  Dynamic Huffman (FGK Algorithm)
-  LZW Compression
-  Arithmetic Coding
-  Step-by-step Tree Visualization
-  Academic Jupyter Notebook Integration
-  Fully Dockerized Deployment

---

##  Algorithms Implemented

### 🔹 Static Huffman Coding
- Tree construction using priority queue
- Code generation
- Encoding and decoding
- Entropy, Efficiency, Redundancy calculation
- Tree visualization

### 🔹 Dynamic Huffman (FGK Algorithm)
- Adaptive tree update
- Block swapping logic
- Step-by-step visualization
- Tree state after each symbol

### 🔹 LZW Compression
- Dictionary initialization
- Encoding and decoding
- Compression ratio calculation

### 🔹 Arithmetic Coding
- Probability calculation
- Interval refinement
- Encoding and decoding
- Graphical interval visualization

---

##  Project Structure
UI-1/
│
├── app.py
├── Dockerfile
├── requirements.txt
├── README.md
├── Docker_execution_file.md
├── Sheethal_BDA_251100670032_ED.ipynb
│
├── templates/
│ ├── home.html
│ ├── static_huffman.html
│ ├── dynamic_huffman.html
│ ├── lzw.html
│ └── arithmetic.html
│
└── static/


---

##  Docker Deployment

### 🔹 Build Image

```bash
docker tag compression-ui sheethalrao94/compression-ui:latest
docker images
docker push sheethalrao94/compression-ui:latest

```
Access the Application
Flask Web Interface:
http://localhost:5000
http://localhost:8888/notebooks/Sheethal_BDA_251100670032_ED.ipynb


## Pull From Docker Hub
```bash
docker pull sheethalrao94/compression-ui:latest
docker run -p 5050:5000 -p 8888:8888 sheethalrao94/compression-ui:latest
docker run -p 5060:5000 -p 8890:8888 sheethalrao94/compression-ui:latest
```#   e n c o d e - d e c o d e r - p r o 
 
 